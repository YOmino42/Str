package com.example.screenlive

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Una scena = ritaglio dello schermo + immagine da URL in sovraimpressione. Valori in %. */
data class Scene(
    val name: String = "Scena 1",
    val cropLeft: Float = 0f,
    val cropTop: Float = 0f,
    val cropRight: Float = 0f,
    val cropBottom: Float = 0f,
    val imageUrl: String = "",
    val imgX: Float = 65f,
    val imgY: Float = 5f,
    val imgScale: Float = 25f,
) {
    fun toJson() = JSONObject()
        .put("name", name).put("l", cropLeft.toDouble()).put("t", cropTop.toDouble())
        .put("r", cropRight.toDouble()).put("b", cropBottom.toDouble())
        .put("url", imageUrl).put("x", imgX.toDouble()).put("y", imgY.toDouble())
        .put("s", imgScale.toDouble())

    companion object {
        fun fromJson(o: JSONObject) = Scene(
            o.optString("name", "Scena"),
            o.optDouble("l", 0.0).toFloat(), o.optDouble("t", 0.0).toFloat(),
            o.optDouble("r", 0.0).toFloat(), o.optDouble("b", 0.0).toFloat(),
            o.optString("url", ""),
            o.optDouble("x", 65.0).toFloat(), o.optDouble("y", 5.0).toFloat(),
            o.optDouble("s", 25.0).toFloat(),
        )
    }
}

object SceneStore {
    fun load(p: SharedPreferences): List<Scene> {
        val raw = p.getString("scenes", null) ?: return listOf(Scene())
        return runCatching {
            val a = JSONArray(raw)
            List(a.length()) { Scene.fromJson(a.getJSONObject(it)) }.ifEmpty { listOf(Scene()) }
        }.getOrDefault(listOf(Scene()))
    }

    fun save(p: SharedPreferences, scenes: List<Scene>) {
        val a = JSONArray()
        scenes.forEach { a.put(it.toJson()) }
        p.edit().putString("scenes", a.toString()).apply()
    }
}

data class StreamConfig(
    val url: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Int,
    val audioMode: Int, // 0 = nessuno, 1 = microfono, 2 = audio interno del telefono
    val scene: Scene,
)
