package com.example.screenlive

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.library.rtmp.RtmpDisplay
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.URL

class StreamService : Service() {

    companion object {
        val status = MutableStateFlow("Fermo")
        val live = MutableStateFlow(false)
        private var instance: StreamService? = null

        fun start(ctx: Context, code: Int, data: Intent, c: StreamConfig) {
            val i = Intent(ctx, StreamService::class.java)
                .putExtra("code", code).putExtra("data", data)
                .putExtra("url", c.url).putExtra("w", c.width).putExtra("h", c.height)
                .putExtra("fps", c.fps).putExtra("bitrate", c.bitrate)
                .putExtra("audio", c.audioMode).putExtra("scene", c.scene.toJson().toString())
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, StreamService::class.java).setAction("STOP"))
        }

        fun applyScene(s: Scene) { instance?.updateScene(s) }
        fun setMute(m: Boolean) { instance?.mute(m) }
    }

    private var display: RtmpDisplay? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val crop = CropFilterRender()
    private var overlay: ImageObjectFilterRender? = null
    private var overlayRatio = 1f
    private var currentUrl = ""
    private var outW = 1280
    private var outH = 720

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) { status.value = "Connessione..." }
        override fun onConnectionSuccess() { status.value = "IN DIRETTA"; live.value = true }
        override fun onConnectionFailed(reason: String) {
            status.value = "Errore: $reason"; shutdown()
        }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() { status.value = "Disconnesso"; live.value = false }
        override fun onAuthError() { status.value = "Chiave non valida"; shutdown() }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { shutdown(); return START_NOT_STICKY }
        instance = this
        val mode = intent.getIntExtra("audio", 1)
        goForeground(mode == 1)

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
        if (data == null) { shutdown(); return START_NOT_STICKY }
        outW = intent.getIntExtra("w", 1280)
        outH = intent.getIntExtra("h", 720)
        val fps = intent.getIntExtra("fps", 30)
        val bitrate = intent.getIntExtra("bitrate", 3000) * 1000
        val url = intent.getStringExtra("url") ?: ""
        val scene = Scene.fromJson(org.json.JSONObject(intent.getStringExtra("scene") ?: "{}"))

        val d = RtmpDisplay(applicationContext, true, checker)
        d.setIntentResult(code, data)
        display = d

        val videoOk = d.prepareVideo(outW, outH, fps, bitrate, 2, 0, 320)
        val audioOk = when (mode) {
            1 -> d.prepareAudio(128 * 1024, 44100, true, true, true)
            2 -> d.prepareInternalAudio(128 * 1024, 44100, true, false, false)
            else -> d.prepareAudio(64 * 1024, 44100, true, false, false).also { d.disableAudio() }
        }
        if (!videoOk || !audioOk) {
            status.value = "Il telefono non supporta questa configurazione"; shutdown()
            return START_NOT_STICKY
        }

        d.glInterface.addFilter(crop)
        updateScene(scene)
        d.startStream(url)
        return START_NOT_STICKY
    }

    private fun updateScene(s: Scene) {
        crop.setCrop(s.cropLeft, s.cropTop, s.cropRight, s.cropBottom)
        if (s.imageUrl != currentUrl) loadOverlay(s) else applyOverlayLayout(s)
    }

    private fun applyOverlayLayout(s: Scene) {
        val f = overlay ?: return
        val sx = s.imgScale
        // mantiene le proporzioni dell'immagine rispetto al frame di uscita
        val sy = (sx * overlayRatio * outW / outH).coerceAtMost(100f)
        f.setScale(sx, sy)
        f.setPosition(s.imgX, s.imgY)
    }

    private fun loadOverlay(s: Scene) {
        currentUrl = s.imageUrl
        overlay?.let { display?.glInterface?.removeFilter(it) }
        overlay = null
        if (s.imageUrl.isBlank()) return
        scope.launch {
            val bmp: Bitmap? = withContext(Dispatchers.IO) {
                runCatching { URL(s.imageUrl).openStream().use { BitmapFactory.decodeStream(it) } }.getOrNull()
            }
            if (bmp == null) { status.value = "Immagine non caricata"; return@launch }
            val f = ImageObjectFilterRender()
            display?.glInterface?.addFilter(f)
            f.setImage(bmp)
            overlay = f
            overlayRatio = bmp.height.toFloat() / bmp.width.toFloat()
            applyOverlayLayout(s)
        }
    }

    private fun mute(m: Boolean) {
        val d = display ?: return
        if (m) d.disableAudio() else d.enableAudio()
    }

    private fun shutdown() {
        runCatching { display?.let { if (it.isStreaming) it.stopStream() } }
        display = null; overlay = null; currentUrl = ""
        live.value = false
        scope.coroutineContext.cancelChildren()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        instance = null
    }

    override fun onDestroy() { shutdown(); super.onDestroy() }

    private fun goForeground(withMic: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("live", "Diretta", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "live")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("ScreenLive")
            .setContentText("Trasmissione schermo attiva")
            .setOngoing(true).build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (withMic && Build.VERSION.SDK_INT >= 30) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        ServiceCompat.startForeground(this, 1, n, type)
    }
}
