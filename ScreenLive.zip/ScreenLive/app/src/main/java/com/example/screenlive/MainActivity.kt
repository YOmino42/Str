package com.example.screenlive

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private var pendingConfig: StreamConfig? = null

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection.launch(mpm.createScreenCaptureIntent())
    }

    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val cfg = pendingConfig
        if (r.resultCode == RESULT_OK && data != null && cfg != null) {
            StreamService.start(this, r.resultCode, data, cfg)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    ScreenLiveUi(
                        onStart = { cfg ->
                            pendingConfig = cfg
                            permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
                        },
                        onStop = { StreamService.stop(this) },
                    )
                }
            }
        }
    }
}

@Composable
fun Sl(label: String, v: Float, max: Float, onChange: (Float) -> Unit) {
    Text("$label: ${v.toInt()}%", style = MaterialTheme.typography.bodySmall)
    Slider(value = v, onValueChange = onChange, valueRange = 0f..max)
}

@Composable
fun ScreenLiveUi(onStart: (StreamConfig) -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("screenlive", Context.MODE_PRIVATE) }
    val live by StreamService.live.collectAsState()
    val status by StreamService.status.collectAsState()

    var platform by remember { mutableStateOf(prefs.getString("platform", "youtube")!!) }
    var key by remember { mutableStateOf(prefs.getString("key_$platform", "")!!) }
    var customBase by remember { mutableStateOf(prefs.getString("custom_base", "rtmp://")!!) }
    var quality by remember { mutableStateOf(prefs.getInt("quality", 1)) }
    var audio by remember { mutableStateOf(prefs.getInt("audio", 1)) }
    var muted by remember { mutableStateOf(false) }

    val scenes = remember { mutableStateListOf<Scene>().apply { addAll(SceneStore.load(prefs)) } }
    var sel by remember { mutableStateOf(0) }
    var scene by remember { mutableStateOf(scenes[0]) }

    fun edit(s: Scene) { scene = s; if (live) StreamService.applyScene(s) }

    val qualities = listOf(
        Triple("480p", 854 to 480, 1500),
        Triple("720p", 1280 to 720, 3000),
        Triple("1080p", 1920 to 1080, 5000),
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("ScreenLive", style = MaterialTheme.typography.headlineSmall)
        Text("Stato: $status")

        // --- Destinazione ---
        Text("Piattaforma", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("youtube" to "YouTube", "twitch" to "Twitch", "custom" to "Altro").forEach { (id, name) ->
                FilterChip(selected = platform == id, onClick = {
                    prefs.edit().putString("platform", id).apply()
                    platform = id; key = prefs.getString("key_$id", "")!!
                }, label = { Text(name) })
            }
        }
        if (platform == "custom") {
            OutlinedTextField(customBase, { customBase = it; prefs.edit().putString("custom_base", it).apply() },
                label = { Text("URL RTMP") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        OutlinedTextField(key, { key = it; prefs.edit().putString("key_$platform", it).apply() },
            label = { Text("Chiave di stream") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())

        // --- Qualità e audio ---
        Text("Qualità", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            qualities.forEachIndexed { i, q ->
                FilterChip(selected = quality == i, onClick = { quality = i; prefs.edit().putInt("quality", i).apply() },
                    label = { Text(q.first) })
            }
        }
        Text("Audio", style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Nessuno", "Microfono", "Audio interno").forEachIndexed { i, n ->
                FilterChip(selected = audio == i, onClick = { audio = i; prefs.edit().putInt("audio", i).apply() },
                    label = { Text(n) })
            }
        }
        Row {
            Text("Muto", Modifier.weight(1f))
            Switch(muted, { muted = it; StreamService.setMute(it) })
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        // --- Scene ---
        Text("Scene", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            scenes.forEachIndexed { i, s ->
                FilterChip(selected = sel == i, onClick = { sel = i; edit(scenes[i]) }, label = { Text(s.name) })
            }
        }
        OutlinedTextField(scene.name, { edit(scene.copy(name = it)) }, label = { Text("Nome scena") },
            singleLine = true, modifier = Modifier.fillMaxWidth())

        Text("Ritaglio schermo (tieni le proporzioni 16:9 per non deformare)", style = MaterialTheme.typography.bodySmall)
        Sl("Taglia sinistra", scene.cropLeft, 90f) { edit(scene.copy(cropLeft = it)) }
        Sl("Taglia destra", scene.cropRight, 90f) { edit(scene.copy(cropRight = it)) }
        Sl("Taglia sopra", scene.cropTop, 90f) { edit(scene.copy(cropTop = it)) }
        Sl("Taglia sotto", scene.cropBottom, 90f) { edit(scene.copy(cropBottom = it)) }

        Text("Immagine da URL", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(scene.imageUrl, { edit(scene.copy(imageUrl = it.trim())) },
            label = { Text("https://...png/jpg") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Sl("Posizione X", scene.imgX, 100f) { edit(scene.copy(imgX = it)) }
        Sl("Posizione Y", scene.imgY, 100f) { edit(scene.copy(imgY = it)) }
        Sl("Dimensione", scene.imgScale, 100f) { edit(scene.copy(imgScale = it.coerceAtLeast(2f))) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { scenes[sel] = scene; SceneStore.save(prefs, scenes) }) { Text("Salva") }
            OutlinedButton(onClick = {
                scenes.add(Scene(name = "Scena ${scenes.size + 1}")); sel = scenes.lastIndex
                SceneStore.save(prefs, scenes); edit(scenes[sel])
            }) { Text("Nuova") }
            OutlinedButton(onClick = {
                if (scenes.size > 1) { scenes.removeAt(sel); sel = 0; SceneStore.save(prefs, scenes); edit(scenes[0]) }
            }) { Text("Elimina") }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            modifier = Modifier.fillMaxWidth().height(56.dp),
            onClick = {
                if (live) onStop() else {
                    val base = when (platform) {
                        "youtube" -> "rtmp://a.rtmp.youtube.com/live2"
                        "twitch" -> "rtmp://live.twitch.tv/app"
                        else -> customBase.trimEnd('/')
                    }
                    val (_, size, br) = qualities[quality]
                    onStart(StreamConfig("$base/${key.trim()}", size.first, size.second, 30, br, audio, scene))
                }
            },
        ) { Text(if (live) "FERMA DIRETTA" else "AVVIA DIRETTA") }
    }
}
