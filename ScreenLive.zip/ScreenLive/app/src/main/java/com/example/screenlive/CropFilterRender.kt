package com.example.screenlive

import android.content.Context
import android.opengl.GLES20
import android.opengl.Matrix
import com.pedro.encoder.input.gl.render.filters.BaseFilterRender
import com.pedro.encoder.utils.gl.GlUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Filtro OpenGL che ritaglia lo schermo catturato e lo allarga a tutto il frame.
 * I margini sono in % (0..100) e si possono cambiare anche durante la diretta.
 */
class CropFilterRender : BaseFilterRender() {

    private val vertexData = floatArrayOf(
        -1f, -1f, 0f, 0f, 0f,
        1f, -1f, 0f, 1f, 0f,
        -1f, 1f, 0f, 0f, 1f,
        1f, 1f, 0f, 1f, 1f,
    )
    private val stride = 5 * 4
    private var program = -1
    private var aPosition = -1
    private var aTexture = -1
    private var uMVP = -1
    private var uST = -1
    private var uSampler = -1
    private var uCrop = -1

    @Volatile private var cx = 0f
    @Volatile private var cy = 0f
    @Volatile private var cw = 1f
    @Volatile private var ch = 1f

    init {
        squareVertex = ByteBuffer.allocateDirect(vertexData.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
        squareVertex.put(vertexData).position(0)
        Matrix.setIdentityM(MVPMatrix, 0)
        Matrix.setIdentityM(STMatrix, 0)
    }

    /** Margini da tagliare in percentuale. */
    fun setCrop(left: Float, top: Float, right: Float, bottom: Float) {
        cx = (left / 100f).coerceIn(0f, 0.9f)
        cw = (1f - (left + right) / 100f).coerceIn(0.05f, 1f)
        // in OpenGL l'origine delle texture è in basso a sinistra
        cy = (bottom / 100f).coerceIn(0f, 0.9f)
        ch = (1f - (top + bottom) / 100f).coerceIn(0.05f, 1f)
    }

    override fun initGlFilter(context: Context?) {
        val vertex = """
            uniform mat4 uMVPMatrix;
            uniform mat4 uSTMatrix;
            attribute vec4 aPosition;
            attribute vec4 aTextureCoord;
            varying vec2 vTextureCoord;
            void main() {
              gl_Position = uMVPMatrix * aPosition;
              vTextureCoord = (uSTMatrix * aTextureCoord).xy;
            }
        """.trimIndent()
        val fragment = """
            precision mediump float;
            uniform sampler2D uSampler;
            uniform vec4 uCrop;
            varying vec2 vTextureCoord;
            void main() {
              gl_FragColor = texture2D(uSampler, uCrop.xy + vTextureCoord * uCrop.zw);
            }
        """.trimIndent()
        program = GlUtil.createProgram(vertex, fragment)
        aPosition = GLES20.glGetAttribLocation(program, "aPosition")
        aTexture = GLES20.glGetAttribLocation(program, "aTextureCoord")
        uMVP = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        uST = GLES20.glGetUniformLocation(program, "uSTMatrix")
        uSampler = GLES20.glGetUniformLocation(program, "uSampler")
        uCrop = GLES20.glGetUniformLocation(program, "uCrop")
    }

    override fun drawFilter() {
        GLES20.glUseProgram(program)
        squareVertex.position(0)
        GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, stride, squareVertex)
        GLES20.glEnableVertexAttribArray(aPosition)
        squareVertex.position(3)
        GLES20.glVertexAttribPointer(aTexture, 2, GLES20.GL_FLOAT, false, stride, squareVertex)
        GLES20.glEnableVertexAttribArray(aTexture)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, MVPMatrix, 0)
        GLES20.glUniformMatrix4fv(uST, 1, false, STMatrix, 0)
        GLES20.glUniform4f(uCrop, cx, cy, cw, ch)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE5)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, previousTexId)
        GLES20.glUniform1i(uSampler, 5)
    }

    override fun disableResources() {
        GlUtil.disableResources(aTexture, aPosition)
    }

    override fun release() {
        GLES20.glDeleteProgram(program)
    }
}
